#ifndef BST_H
#define BST_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
#include <map>
using namespace std;
//Todd Larson
//861106862
// 5-11-15
//using the code from assignment 3 to make the functions for lab5
#define nil 0
// #define Value int // restore for testing
template < typename Value >
class BST {
class Node { // binary tree node
public:
Value value;
Node* left;
Node* right;
Node( const Value v = Value() )
: value(v), left(nil), right(nil)
{}
Value& content() { return value; }
bool isInternal() { return left != nil && right != nil; }
bool isExternal() { return left != nil || right != nil; }
bool isLeaf() { return left == nil && right == nil; }
int height() {
    if(this==nil)
        return 0;
    else
    {
        int left_side= left->height();
        int right_side= right->height();// counts to see if the left or the right path is the longest
        
        if(left_side>right_side)//return the longest path or depth
            return left_side+1;
        else 
            return right_side+1;
    }
}
int size() {
    if(left==nil)
    {
        if(right==nil)
            return 1;
        return right->size() + 1;//checks to see it each node has a child
    }
    else if(right==nil)// and if it does adds one to the total
    {
        if(left==nil)
            return 1;
        return left->size()+1;
    }
    return left->size() + right->size() + 1;// until all the nodes are accounted for

return 0;
}
void preorder_help()
{
    cout<<value<<" ";// prints the value before the recusive call
    if(left!=nil)
        left->preorder_help();
    if(right!=nil)
        right->preorder_help();
    
    return;
}
void postorder_help()
{
    if(left!=nil)
        left->postorder_help();
    if(right!=nil)
        right->postorder_help();
    cout<<value<<" ";// prints the value after the recursive calss
    return;
}
void inorder_help()
{
    if(left!=nil)
        left->inorder_help();
    cout<<value<<" ";// prints the value during the recurisve calls
    if(this->right!=nil)
        right->inorder_help();
    return;
    
}
void displayMinCover(int &c)
{
    if(this==nil)
    {
        return;
    }
    if(isLeaf())
    {
        return;
    }
    else
    {
        if(left!=nil)
        {
            c++;
            this->left->displayMinCover(c);
        }
        cout<<value<<" ";
        if(right!=nil)
        {
            c++;
            this->right->displayMinCover(c);
        }
    }
}
void vertSum(Node *n,int hd, std::map<int,int> &m)
{
    if(n==nil)
        return;
    if(n->isLeaf())
    {
        m[hd]+=n->value;
        return;
    }
    else
    {
        m[hd]+=n->value;
        vertSum(n->left,hd-1,m);
        vertSum(n->right,hd+1,m);
        return;
    }
}
};//Node
int count;
Node* root;

public:
int size() {
    return root->size(); // calls the node size function on the root
}
bool empty() { return size() == 0; }
void print_node( const Node* n ) {// prints the node if it is not empty
    if(n!=nil)
        cout<<n->value;
    else 
        cout<<"Empty node."<<endl;
    return;
}
bool search ( Value x ) {// searches for the value 
    if(root->value==x)
        return true;
    else if(root->isLeaf())
        return false;
    else
     return search_help(root,x);
}
void preorder()const {// prints the parent nodes before the children
    if(root!=nil)
        root->preorder_help();
    return;
    
}
void postorder()const {// prints the parent nodes after the children
    if(root!=nil)
        root->postorder_help();
    return;
}
void inorder()const {// prints the nodes in order
    if(root!=nil)
        root->inorder_help();
    return;
}
Value& operator[] (int n) {// finds the value of a node at a specific destination
    if(n<=size()-1)
    {
           return help_op(root,n)->value;
    }
    else
    {
        cout<<"to large of a number."<<endl;
        return root->value;
    }
}
BST() : count(0), root(nil) {}
void insert( Value X ) { root = insert( X, root ); }
Node* insert( Value X, Node* T ) {// inserts a new node
if ( T == nil ) {
T = new Node( X ); // the only place that T gets updated.
} else if ( X < T->value ) {
T->left = insert( X, T->left );
} else if ( X > T->value ) {
T->right = insert( X, T->right );
} else {
T->value = X;
}
// later, rebalancing code will be installed here
return T;
}
void remove( Value X ) { root = remove( X, root ); }// removes an old node
Node* remove( Value X, Node*& T ) {
// The normal binary-tree removal procedure ...
// Weiss’s code is faster but way more intricate.
if ( T != nil ) {
if ( X > T->value ) {
T->right = remove( X, T->right );
} else if ( X < T->value ) {
T->left = remove( X, T->left );
} else {
// X == T->value
if ( T->right != nil ) {
Node* x = T->right;
while ( x->left != nil ) x = x->left;
T->value = x->value; // successor’s value
T->right = remove( T->value, T->right );
} else if ( T->left != nil ) {
Node* x = T->left;
while ( x->right != nil ) x = x->right;
T->value = x->value; // predecessor’s value
T->left = remove( T->value, T->left );
} else { // *T is external
delete T;
T = nil; // the only updating of T
}
}
}
// later, rebalancing code will be installed here
return T;
}
void okay( ) { okay( root ); }
void okay( Node* T ) {
// diagnostic code can be installed here
return;
}
bool search_help(const Node* temp,const Value y)
{//helps the search function find the value
    if(temp==nil)
        return false;
    else if(temp->value==y)
        return true;
    else if(temp->left==nil)
    {
        if(temp->right==nil)
            return false;
        else
            return search_help(temp->right,y);
    }
    else if(temp->right==nil)
    {
        if(temp->left==nil)
            return false;
        else
            return search_help(temp->left,y);
    }
    else
    {
        return search_help(temp->left,y)|| search_help(temp->right, y);
    }
}
int test_height()
{
    return root->height();
}
Node* help_op(Node* a,int n)
{
    if(a==nil)
        return;
    help_op(a->left,n);
    n--;
    help_op(a->right,n);
}
void minCover()
{
    cout<<"Part 1"<<endl;
    int count =0;
    if(root->isLeaf())
    {
        cout<<"0"<<endl;
        return;
    }
    else
    {
        root->left->displayMinCover(count);
        root->right->displayMinCover(count);
        cout<<endl<<count-2;
    }
    cout<<endl;
}
void printBuffy(int total,int buffer[])
{
    list<int> bob;
    for(int i=0;i<total;i++)
    {
        bob.push_back(buffer[i]);
    }
    bob.sort();
    list<int>:: iterator i;
    for(i=bob.begin();i!=bob.end();i++)
    {
        cout<<*i<<" ";
    }
    return;
}
void pathHelper(Node *n,int a, int sum,int find,int buffer[])
{
    if(n==nil)
        return;
    buffer[find]=n->value;
    find++;
    a+=n->value;
    
    if(n->isLeaf()&&a==sum)
    {
        printBuffy(find,buffer);
        return;
    }
    if(n->left!=nil)
        pathHelper(n->left,a,sum,find,buffer);
    if(n->right!=nil)
        pathHelper(n->right,a,sum,find,buffer);
        
}
void findSumPath(int num,int buffer[])
{
    cout<<"Part 2"<<endl;
    pathHelper(root,0,num,0,buffer);
    cout<<endl;
}
void Sum()
{
    cout<<"Part 3"<<endl;
    std::map<int,int> sally;
    root->vertSum(root,0,sally);// i made vertSum a helper function that 
    map<int,int>:: iterator i;//does all the work
    for(i=sally.begin();i!=sally.end();i++)//and this prints it out
    {
        cout<<i->second<<" ";
    }
    cout<<endl;
    return;
}


}; // BST
#endif