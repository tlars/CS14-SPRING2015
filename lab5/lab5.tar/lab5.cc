#include "lab5.h"
#include <iostream>
using namespace std;
//Todd Larson
//861106862
// 5-11-15
int main()
{
    BST<int> bob;
    bob.insert(50);
    bob.insert(20);
    bob.insert(60);
    bob.insert(10);
    bob.insert(70);
    bob.insert(40);
    bob.insert(45);
    bob.insert(35);
    //bob.insert(5);
    //bob.inorder();
    //bob.preorder();
    //cout<<"Part 1"<<endl;
    bob.minCover();
    //cout<<endl;
    int buf[10];
    //cout<<"Part 2"<<endl;
    bob.findSumPath(80,buf);
    //cout<<"Part 3"<<endl;
    bob.Sum();// this is the function vertsum
    //cout<<endl;
    return 0;
}