//lab 3
//Todd Larson
//861106862
//04-21-2015
#include "lab3.h"
#include <iostream>
#include <stack>
using namespace std;

int main()
{
    TwoStackOptimal<int> bob(10);
    // TwoStackFixed<int> bob(10,5);
    bob.pushStack1(5);//1
    bob.pushStack1(4);//2
    bob.pushStack1(4);//3
    bob.pushStack1(4);//4
    bob.pushStack1(4);//5
    bob.pushStack1(3);//6
    //bob.popStack1();
    //bob.popStack1();
    //bob.popStack1();
    bob.popStack2();
    bob.pushStack2(5);//8
    bob.pushStack2(4);//7
    bob.pushStack2(4);//6
    bob.pushStack2(4);//5
    bob.pushStack2(4);//full
    bob.pushStack2(3);//full
    if(bob.isFullStack1())
        cout<<"full"<<endl;
    else
        cout<<"not full"<<endl;
    bob.popStack2();
    if(bob.isFullStack2())
        cout<<"full"<<endl;
    else
        cout<<"not full"<<endl;
    bob.popStack1();
    bob.popStack1();
    bob.popStack1();
    bob.popStack1();
    bob.popStack1();
    if(bob.isEmptyStack1())
        cout<<"empty"<<endl;
    else
        cout<<"not empty"<<endl;
    bob.popStack2();
    if(bob.isEmptyStack2())
        cout<<"empty"<<endl;
    else
        cout<<"not empty"<<endl;
    //testing for towers of hanoi
    stack<int> a;
    stack<int> b;
    stack<int> c;
    int y=3;
   // a.push(4);
    a.push(3);
    a.push(2);
    a.push(1);
    showTowerStates(y,a,b,c);
    while(!c.empty())
    {
        cout<<c.top()<<endl;
        c.pop();
    }
    return 0;
}