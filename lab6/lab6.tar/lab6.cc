//Todd Larson
//861106862
// 5/12/15

#include "selctionsort.h"
#include <iostream>
#include <list>
#include <vector>
#include <utility>

int main()
{
    std::list<int> bob;
    bob.push_back(2);
    bob.push_back(4);
    bob.push_back(5);
    bob.push_back(1);
    bob.push_back(8);
    bob.push_back(9);
    std::list<int>:: iterator j;
    std::cout<<"pre: ";
    for(j=bob.begin();j!=bob.end();j++)
   {
       std::cout<<*j<<" ";
   }
   std::cout<<'\n';
    selctionsort(bob);
    std::cout<<"post: ";
    for(j=bob.begin();j!=bob.end();j++)
   {
       std::cout<<*j<<" ";
   }
   std::cout<<'\n';
    std::list<std::pair<int,int>> lisa;
    lisa.push_back(std::make_pair(1,2));
    lisa.push_back(std::make_pair(3,-1));
    lisa.push_back(std::make_pair(-1,3));
    lisa.push_back(std::make_pair(0,0));
    lisa.push_back(std::make_pair(2,3));
    lisa.push_back(std::make_pair(1,2));
    lisa.push_back(std::make_pair(1,-2));
    lisa.push_back(std::make_pair(8,10));
    std::cout<<"pre: ";
    std::list<std::pair<int,int>>:: iterator i;
   for(i=lisa.begin();i!=lisa.end();i++)
   {
       std::cout<<"("<<i->first<<", "<<i->second<<") ";
   }
   std::cout<<'\n';
    selctionsort(lisa);
     std::cout<<"post: ";
   for(i=lisa.begin();i!=lisa.end();i++)
   {
       std::cout<<"("<<i->first<<", "<<i->second<<") ";
   }
   moves();
   std::list<char> mona;
    std::list<char>:: iterator k;
    std::cout<<"pre: ";
    for(k=mona.begin();k!=mona.end();k++)
   {
       std::cout<<*k<<" ";
   }
   std::cout<<'\n';
    selctionsort(mona);
    std::cout<<"post: ";
    for(k=mona.begin();k!=mona.end();k++)
   {
       std::cout<<*k<<" ";
   }
   std::cout<<'\n';
   std::list<std::pair<int,int>> paul;
    paul.push_back(std::make_pair(-1,3));
    paul.push_back(std::make_pair(0,0));
    paul.push_back(std::make_pair(1,-2));
    paul.push_back(std::make_pair(1,2));
    paul.push_back(std::make_pair(1,2));
    paul.push_back(std::make_pair(2,3));
    paul.push_back(std::make_pair(3,-1));
    paul.push_back(std::make_pair(8,10));
    std::cout<<"pre: ";
    std::list<std::pair<int,int>>:: iterator y;
   for(y=paul.begin();y!=paul.end();y++)
   {
       std::cout<<"("<<y->first<<", "<<y->second<<") ";
   }
   std::cout<<'\n';
    selctionsort(paul);
     std::cout<<"post: ";
   for(y=paul.begin();y!=paul.end();y++)
   {
       std::cout<<"("<<y->first<<", "<<y->second<<") ";
   }
   moves();
    std::list<std::pair<int,int>> p;
    p.push_back(std::make_pair(1,1));
    p.push_back(std::make_pair(1,1));
    p.push_back(std::make_pair(1,1));
    p.push_back(std::make_pair(1,1));
    p.push_back(std::make_pair(1,1));
   for(y=p.begin();y!=p.end();y++)
   {
       std::cout<<"("<<y->first<<", "<<y->second<<") ";
   }
   std::cout<<'\n';
    selctionsort(p);
     std::cout<<"post: ";
   for(y=p.begin();y!=p.end();y++)
   {
       std::cout<<"("<<y->first<<", "<<y->second<<") ";
   }
   moves();// moves should be 0 to show that this is stable
    return 0;
}