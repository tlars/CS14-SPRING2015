//Todd Larson
//861106862
//5/12/15
/*
Approach
I just used the simple approach of using nested for loops.
So when a list with n elements gets passed through
the outer loop will run n times and the inner loop will run n-1 times.
n*(n-1)= n^2-n which is O(n^2).
My sort is stable because when i compare the the next element to the min
i use the < operator than the <= operator. So which ever element comes first
will be before the element that has the same value that came after it.
*/
#include <list>
#include <vector>
#include <iostream>
#include <utility>
int move_count;
template <typename L> void selctionsort(L &l)
{
   auto i=l.begin();
   move_count=0;
   for(i=l.begin();i!=l.end();i++)
   {
       auto min=i;
       for(auto j=i;j!=l.end();j++)
       {
           if(*j<*min)
            min=j;
       }
       if(min!=i)
       {
           move_count++;
           std::swap(*min,*i);
       }
   }
   
}
void moves()
{
    std::cout<<'\n'<<"0 copies and "<<move_count*3<<" moves."<<'\n';
}

