#ifndef LAB2_H
#define LAB2_H
#include <iostream>
#include <forward_list>
using namespace std;
//Todd Larson
//861106862
// 4/14/15
template <class Type> class Node
{
    Type data;
    Node<Type> *next;
    Node<Type>(Type data): data(data), next(0){};
};
template <class Type> class List
{
    protected:
        Node<Type> *head;
    public:
        List();
        void push_front(Type);
        List <Type> elementSwap(List<Type>, int);
        
};
#endif
template <class Type>
List<Type>::List()
{
    head = NULL;
}
template <class Type>
void List<Type>:: push_front(Type t)
{
    Node<Type> *temp=new Node<Type>(t);
    if(head==NULL)
    {
        head=temp;
        head->next=0;
    }
    else if(head->next==0)
    {
        temp->next = head;
        head->next =0;
        head= temp;
    }
    else
    {
        temp->next = head;
        head=temp;
    }
}
//function #2
template <class Type>
List<Type> List<Type>::elementSwap(List<Type> l, int pos)
{ 
    Node<Type> *curr=head;
    if(head==NULL)
    {
        cout<<"Nothing to switch"<<endl;
        return l;
    }
    if(head->next==0)
    {
        cout<<"Only one element"<<endl;
        return l;
    }
    else
    {
        if(pos==0)
        {
            curr->next = head->next->next;
            curr->next=head;
            head=curr;
        }
        else
        {
            for(int i=0; i<pos-1;i++)
            {
                curr=curr->next;
            }
            Node<Type> *after=curr->next;
            after->next=after->next->next;
            after->next = after;
            curr->next = after;
            
        }
    }
}

