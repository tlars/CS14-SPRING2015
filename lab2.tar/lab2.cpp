//lab 2
//Todd Larson
//861106862
//04-14-2015
#include "lab2.h"
#include <iostream>
using namespace std; 

// helper function for #1
bool isPrime(int i)
{
    if(i==1 || i==0)
    {
        return false;
    }
    else if(i==2 || i==3 || i==5 || i==7)
    {
        return true;
    }
    for(int j=2; j<=9;j++)
    {
        if(i%j==0)
        {
            return false;
        }
    }
    return true;
}
//function 1
int primeCount(forward_list<int> lst)
{
    if(lst.begin()!=lst.end())
    {
        if(isPrime(*lst.begin()))
        {
            lst.pop_front();
            return 1 + primeCount(lst);
        }
        else
        {
            lst.pop_front();
            return 0 + primeCount(lst);
        }
    }
    else
    {
        return 0;
    }
}// function 3
template <typename type>
forward_list <type>list_Copy(forward_list<type> l,forward_list<type> p)
{
    typename forward_list<type>:: iterator i;
    int count=0;
    for(i =p.begin();i != p.end();i++)
    {
        count++;
    }
    for(int i=0;i<count;i++)
    {
        p.pop_front();
    }
    for(i =l.begin();i != l.end();i++)
    {
        p.push_front(*i);
    }
    return p;
}//works
//function 4
template <typename Type>
void printLots(forward_list<Type> l, forward_list<int> num)
{
    typename forward_list<int>:: iterator i;
    typename forward_list<Type>:: iterator j;
    for(i=num.begin();i != num.end();i++)
    {
        
        j= l.begin();
        for(int k=1; k<*i;k++)
        {
            j++;
        }
        cout<<*j<<" ";
    }
    
}

int main()
{
    forward_list<int> bob;
    bob.push_front(11);
    bob.push_front(31);
    bob.push_front(2);
    bob.push_front(43);
    forward_list<int> mike;
    //list <int> smity;
    int billy = primeCount(bob);
    cout<<billy<<endl;
    //mike = list_Copy(bob,mike);
    //forward_list<int> smity;
    mike.push_front(19);
    mike.push_front(45);
    mike.push_front(66);
    mike.push_front(100);
    forward_list<int>:: iterator k;
    bob=list_Copy(mike,bob);
    for(k=bob.begin();k!= bob.end();k++)
    {
        cout<< *k <<" ";
    }
    //cout<<endl;
    //printLots(smity,bob);
   // list<int>:: iterator i;
    //bob=elementSwap(smity,2);
    //for(i=bob.begin();i!= bob.end();i++)
    //{
      //  cout<< *i <<" ";
    //}
    return 0;

}