//lab 4
//Todd Larson
//861106862
//04-28-2015
#include "lab4.h"
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    if(argc!=2)
    {
        cout<<"Use correct input."<<endl;
        exit(0);
    }
    int a= (int) *argv[1]-'0';
    post_order(a,1);
    pre_order(a,1);
    in_order(a,1);
    return 0;
}