#ifndef LAB4_H
#define LAB4_H
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
//Todd Larson
//861106862
// 4/28/15


typedef pair<int,int> Entry;
class priority_queue
{
    public:
    vector<Entry> entries;
    Entry& front(){ return entries.back();}
    void pop(){entries.pop_back();}
    void push(Entry e)
    {
        entries.push_back(e);
        for(int i= entries.size()-1;i!=0;i--)
        {
            if(entries[i]<=entries[i-1])
                break;
            swap(entries[i],entries[i-1]);
        }
    }
    void print()
    {
        for(int i=entries.size()-1;i>=0;i--)
        {
            cout<<entries[i].first<<" "<<entries[i].second<<endl;
        }
    }
    
};



void pre_helper(int m, int n,int k)
{
    if((3*m)-n<k)
    {
        cout<<(2*m)-n<<" "<<(m)<<endl;
        pre_helper(((2*m)-n),m,k);
    }
    if((3*m)+n<k)
    {
        cout<<((2*m)+n)<<" "<<m<<endl;
        pre_helper((2*m)+n,m,k);
    }
    if(m+(3*n)<k)
    {
        cout<<(m+(2*n))<<" "<<n<<endl;
        pre_helper(m+(2*n),n,k);
    }
    return;

    
}
void post_helper(int m, int n,int k)
{
    if((3*m)-n<k)
    {
        post_helper(((2*m)-n),m,k);
        cout<<(2*m)-n<<" "<<(m)<<endl;
    }
    if((3*m)+n<k)
    {
        post_helper((2*m)+n,m,k);
        cout<<((2*m)+n)<<" "<<m<<endl;
    }
    if(m+(3*n)<k)
    {
        post_helper(m+(2*n),n,k);
        cout<<(m+(2*n))<<" "<<n<<endl;
    }
    return;

    
}
typedef pair<int,int> Entry;
priority_queue smity;
void in_helper(int m, int n, int k)
{
    if((3*m)-n<k)
    {
        smity.push(Entry((2*m)-n,m));
        in_helper(((2*m)-n),m,k);
    }
    if((3*m)+n<k)
    {
        smity.push(Entry((2*m)+n,m));
        in_helper(((2*m)+n),m,k);
    }
    if(m+(3*n)<k)
    {
        smity.push(Entry((2*n)+m,n));
        in_helper(((2*n)+m),n,k);  
    }
    return;
}
void pre_order(int m, int n)
{
    cout<<"Pre-order:"<<endl;
    cout<<"2 1"<<endl;
    pre_helper(2,1,m);
    cout<<"3 1"<<endl;
    pre_helper(3,1,m);
    return;
}
void post_order(int m, int n)
{
    cout<<"Post order:"<<endl;
    post_helper(2,1,m);
    cout<<"2 1"<<endl;
    post_helper(3,1,m);
    cout<<"3 1"<<endl;
    return;
}
typedef pair<int,int> Entry;
void in_order(int m,int n)
{
    cout<<"Sorted: "<<endl;
    cout<<"2 1"<<endl;
    in_helper(2,1,m);
    cout<<"3 1"<<endl;
    in_helper(3,1,m);
    smity.print();
}
#endif

